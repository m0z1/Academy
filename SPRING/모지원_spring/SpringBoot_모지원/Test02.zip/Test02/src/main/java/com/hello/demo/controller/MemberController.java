package com.hello.demo.controller;

import java.lang.reflect.Member;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hello.demo.dto.MemberDTO;
import com.hello.demo.service.MemberService;

import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@Controller
public class MemberController {
	
	@Autowired
	private final MemberService memberService;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}

	
	@GetMapping("/joining")
	public String join() {
		return "/user/join";
	}
	
	@PostMapping("/join")
	@ResponseBody
	public String join(@RequestBody MemberDTO member) {
		MemberDTO m = new MemberDTO();
		m.setAddr(member.getAddr());
		m.setId(member.getId());
		m.setName(member.getName());
		m.setPass(member.getPass());
		memberService.join(member);
		return "success";
	}
	
	@GetMapping({"main","list"})
	public String list(MemberDTO member, Model model) {
		List<MemberDTO> members = memberService.list();
		model.addAttribute("member",members);
		return "list";
	}
}
