package com.hello.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hello.demo.dto.MemberDTO;

public interface MemberRepository extends JpaRepository<MemberDTO, Long>{

}
