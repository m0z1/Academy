package com.hello.demo.mapper;

public interface MemberMapper {

}
