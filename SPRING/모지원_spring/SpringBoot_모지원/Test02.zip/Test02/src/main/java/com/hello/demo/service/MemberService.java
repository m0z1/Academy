package com.hello.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hello.demo.dto.MemberDTO;
import com.hello.demo.repository.MemberRepository;

import lombok.RequiredArgsConstructor;



@RequiredArgsConstructor
@Service
public class MemberService {
	
	private final MemberRepository memberRepositorty;
	
	public List<MemberDTO> list(){
		return memberRepositorty.findAll();
		
	}
	
	@Transactional
	public void join(MemberDTO member) {
		memberRepositorty.save(member);
	}
	
	
	
}
