rootProject.name ="naveridlogin-sdk-android"

include (
    ":Nid-OAuth",
    ":Samples"
)
