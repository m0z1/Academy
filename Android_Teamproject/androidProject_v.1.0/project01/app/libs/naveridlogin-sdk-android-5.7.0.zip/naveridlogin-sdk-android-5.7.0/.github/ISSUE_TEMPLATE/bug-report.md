---
name: Bug Report
about: 버그를 제보해주세요.
title: "[Bug Report]"
labels: Bug Report
assignees: ''

---

# Bug Report
## 재현 환경
### 사용중인 네아로 SDK 버전

### Android 버전

### 재현되는 기기 모델명

## 이슈
### 이슈 명세

### 기대한 결과

### 실제 결과

### 재현 시나리오

### Stack trace
```
```

### Reference
