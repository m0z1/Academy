package com.example.androidproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AndroidprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AndroidprojectApplication.class, args);
	}

}
