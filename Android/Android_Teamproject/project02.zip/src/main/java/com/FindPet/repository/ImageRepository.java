package com.FindPet.repository;

public interface ImageRepository {

}
