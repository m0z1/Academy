package com.FindPet.repository;

public interface CommentRepository {

}
