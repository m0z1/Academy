package com.FindPet.repository;

public interface StoryBoardRepository {

}
