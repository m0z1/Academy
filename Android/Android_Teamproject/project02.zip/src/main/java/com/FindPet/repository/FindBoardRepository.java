package com.FindPet.repository;

public interface FindBoardRepository {

}
